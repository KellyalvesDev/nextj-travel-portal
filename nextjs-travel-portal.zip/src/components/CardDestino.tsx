import Link from 'next/link';
import styles from '../styles/CardDestino.module.css';

type Destino = { id:number; nome:string; imagem:string };

export default function CardDestino({ destino }: { destino: Destino }) {
  return (
    <div className={styles.card}>
      <img src={destino.imagem} alt={destino.nome}/>
      <h3>{destino.nome}</h3>
      <Link href={'/destinos/' + destino.id}>Ver detalhes</Link>
    </div>
  );
}