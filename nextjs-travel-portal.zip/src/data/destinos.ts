export default [
  { id:1, nome:'Paris', imagem:'https://picsum.photos/300?1', descricao:'A cidade luz.' },
  { id:2, nome:'Tokyo', imagem:'https://picsum.photos/300?2', descricao:'Tecnologia e tradição.' },
  { id:3, nome:'Rio de Janeiro', imagem:'https://picsum.photos/300?3', descricao:'Praias e montanhas.' },
  { id:4, nome:'Nova York', imagem:'https://picsum.photos/300?4', descricao:'A cidade que nunca dorme.' }
];