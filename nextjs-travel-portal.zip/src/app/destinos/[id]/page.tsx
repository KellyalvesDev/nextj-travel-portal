import destinos from '../../../data/destinos';

export default function DestinoDetalhe({ params }: any) {
  const destino = destinos.find(d => d.id === parseInt(params.id));

  if (!destino) return <p>Destino não encontrado.</p>;

  return (
    <div>
      <h1>{destino.nome}</h1>
      <img src={destino.imagem} width="400"/>
      <p>{destino.descricao}</p>
    </div>
  );
}