import destinos from '../../data/destinos';
import CardDestino from '../../components/CardDestino';

export default function DestinosPage() {
  return (
    <div>
      <h1>Destinos</h1>
      <div style={{display:'flex',gap:'20px',flexWrap:'wrap'}}>
        {destinos.map(dest => (
          <CardDestino key={dest.id} destino={dest}/>
        ))}
      </div>
    </div>
  );
}