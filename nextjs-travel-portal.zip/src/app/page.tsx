export default function Home() {
  return (
    <div>
      <h1>Portal de Viagens</h1>
      <p>Descubra destinos incríveis ao redor do mundo.</p>
      <a href="/destinos">Ver destinos</a>
    </div>
  );
}