export default function Home() {
  return (
    <main style={{ padding: 20 }}>
      <h1>Travel Portal</h1>
      <p>Bem-vinda ao portal de viagens!</p>
    </main>
  );
}
